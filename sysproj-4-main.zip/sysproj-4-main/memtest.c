#include <stdlib.h>
#include <stdio.h>

int main (int argc, char **argv){

  char* x = malloc(24);
  char* y = malloc(19);
  char* z = malloc(32);
  
  printf("x = %p\n", x);
  printf("y = %p\n", y);
  printf("z = %p\n", z);

  char* a = realloc(x, 20);
  char* b = realloc(x, 30);
  printf("a = %p\n", a);
  printf("b = %p\n", b);

  //Allocate a block of size 19  using malloc and store it in c
  char* c = malloc(19);
  printf("c = %p\n", c);

  //free blocks c,y,z to push blocks of sizes 24,19,32 onto the free block list
  free(c);
  free(y);
  free(z);

  //Allocate a block of size 23 using malloc() and allocate it to d
  char* d = malloc(23);
  printf("d = %p\n", d);

  //Allocate a block of size 22 using malloc()
  char* e = malloc(22);
  printf("e = %p\n", e);
  
}
