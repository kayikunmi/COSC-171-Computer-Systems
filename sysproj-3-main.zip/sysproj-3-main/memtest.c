#include <stdlib.h>
#include <stdio.h>

int main (int argc, char **argv){

  char* x = malloc(24);
  char* y = malloc(19);
  char* z = malloc(32);
  
  printf("x = %p\n", x);
  printf("y = %p\n", y);
  printf("z = %p\n", z);

  printf("%s\n", "Test 1: No address change");
  printf("x = %p\n", x);
  x = realloc(x, 20);
  printf("x = %p\n", x);
  printf("\n");

  printf("%s\n", "Test 2: Change address and copy contents over");
  *y = 'a';
  char* y2 = y + 1;
  *y2 = 'b';
  printf("y = %p\n", y);
  printf("%d\n", *y);
  printf("%d\n", *y2);
  y = realloc(y, 33);
  printf("y = %p\n", y);
  printf("%d\n", *y);
  printf("%d\n", *y2);
  printf("\n");

  printf("%s\n", "Test3: No address change");
  printf("z = %p\n", z);
  z = realloc(z, 32);
  printf("z = %p\n", z);


}
